#! /usr/bin/env python3
"""Module to scrap book information from goodreads
"""

__version__ = '0.0.1'




def bookscraper():
  print("Teste")